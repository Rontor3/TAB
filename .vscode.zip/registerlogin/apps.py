from django.apps import AppConfig


class RegisterloginConfig(AppConfig):
    name = 'registerlogin'
