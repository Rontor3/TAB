from django.contrib import admin
from registerlogin.models import Profile

# Register your models here.
admin.site.register(Profile)
