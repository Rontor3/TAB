from django.contrib import admin
from Place.models import Basic_travel,Destination_image,Destination_tour,type_hotel,Place,mode_of_travel,explore_route,location_destination,Acti
# Register your models here.
admin.site.register(Basic_travel)
admin.site.register(Destination_tour)
admin.site.register(Destination_image)
admin.site.register(type_hotel)
admin.site.register(Place)
admin.site.register(mode_of_travel)
admin.site.register(explore_route)
admin.site.register(location_destination)
admin.site.register(Acti)
